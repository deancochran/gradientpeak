# Complete review activity-plan catalog

`gradientpeak-complete-catalog-a5-top-bound-reader.pdf` is a **91-page** A5 (148 × 210 mm) portrait, screen/local-proof reader edition. Print at **100% / actual size** in portrait orientation; do not use “fit to page”.

The adjacent `gradientpeak-complete-catalog-a5-top-bound-reader.validation.json` and `.validation.md` record the deterministic whole-catalog schema, coverage, execution, total, and layout audit.

## Reader glossary

The reader’s dedicated glossary defines every abbreviated target, unit, and pace notation used in the catalog, including FTP, THR / Threshold HR, HRmax / MaxHR, HR / bpm, RPE, rpm, CSS, VO2, W, and 5K. Conversion-table lookup intervals use 10%; calculate or interpolate from reference × percentage ÷ 100 between them. Built-in prescriptions retain their authored five-percentage-point grid. The conversion tables use the authored reference named by each target; HRmax and THR are not interchangeable.

This reader edition is A5 top-bound Wire-O at 100% / actual size. It contains only reader pages—no blank reverse clutter. The matching duplex upload interior preserves reader pages 2–90 once each in normal upright reading order, followed by one final blank reverse face to make 90 interior faces; it does not insert blanks between content pages. Its separate four-face cover retains the existing front, blank inside front, blank inside back, and back mapping. The manifest maps reader page numbers to upload faces. The package contains 89 content interior faces plus one final blank reverse and four cover faces: 94 faces / 47 leaves when cover stock is counted separately. Use one copy: A5, top-bound Wire-O, double-sided printing, normal upright reading order. The upload files have 0.125 in (9 pt) bleed geometry. Confirm the chosen online printer supports the selected binding and stock; no vendor approval or production guarantee is made. Eight system templates are excluded from this publisher edition only and remain in the application catalog and training schedules. No CMYK or PDF/X claim is made for this local review/upload package.
