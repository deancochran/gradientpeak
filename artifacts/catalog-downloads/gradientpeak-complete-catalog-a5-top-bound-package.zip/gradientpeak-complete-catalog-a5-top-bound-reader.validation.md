# Complete review catalog validation

- Front matter: **10** reader pages (front cover, contents, user guide, and conversion tables; no publication-information page)
- Workout allocation: **66** workouts use their actual natural number of content pages = **74** pages; no blank workout pages are allocated.
- Back matter: **1** reader page (back cover)
- Contents references: **66** workouts and **0** training schedules

# Styled distance-reading catalog validation

- PDF pages: **91** (A5 148 × 210 mm portrait)
- Workouts: **66**; training templates: **0**
- Workout content pages: **74**; each workout uses its actual natural number of content pages (the same **74** physical pages total). No blank workout pages are allocated.
- Structural checks: **passed** — valid V5 schema, source/printed step coverage, execution order and repeats, raw-schema totals, full chart execution trace, cue-context preservation, and rendered safe bounds/footer separation.
- Content review findings: **0**. These non-blocking findings do not determine coaching correctness or authorize prescription edits.

## Longest workouts

| Workout | Content pages | Physical allocation | Warnings |
| --- | ---: | ---: | --- |
| Compound Strength | 2 | 2 | mixed duration units: repetitions, time |
| Lower Body Strength | 2 | 2 | mixed duration units: repetitions, time |
| Mobility Reset | 2 | 2 | — |
| Single-Leg Control | 2 | 2 | mixed duration units: repetitions, time |
| Swimming CSS Assessment — 400 m / 200 m | 2 | 2 | mixed duration units: distance, time |
| Track Ladder Activity | 2 | 2 | mixed duration units: distance, time |
| Upper Body Strength | 2 | 2 | mixed duration units: repetitions, time |
| Yoga Balance Flow | 2 | 2 | — |
| 5K Pace Intervals | 1 | 1 | — |
| Aerobic Continuity Swim | 1 | 1 | mixed duration units: distance, time |

## Per-workout audit

| Workout | Content pages | Physical allocation | Duration kinds | Target types | Unsupported targets | Content review | Warnings |
| --- | ---: | ---: | --- | --- | ---: | --- | --- |
| Cycling FTP Assessment | 1 | 1 | time | RPE | 0 | — | — |
| Running Threshold Pace Assessment | 1 | 1 | time | RPE | 0 | — | — |
| Swimming CSS Assessment — 400 m / 200 m | 2 | 2 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| VO2 Max Development | 1 | 1 | time | %FTP | 0 | — | — |
| Sprint Power Development | 1 | 1 | time | %FTP, RPE | 0 | — | — |
| Threshold Heart Rate Intervals | 1 | 1 | time | %ThresholdHR | 0 | — | — |
| Sweet Spot Intervals | 1 | 1 | time | %FTP | 0 | — | — |
| VO2 Max Intervals | 1 | 1 | time | %FTP | 0 | — | — |
| FTP Intervals | 1 | 1 | time | %FTP | 0 | — | — |
| Threshold Run Development 1 | 1 | 1 | time | %ThresholdHR | 0 | — | — |
| Threshold Run Development 2 | 1 | 1 | time | %ThresholdHR | 0 | — | — |
| Speed Intervals | 1 | 1 | time | %ThresholdHR | 0 | — | — |
| Hill Intervals | 1 | 1 | time | %ThresholdHR | 0 | — | — |
| 5K Pace Intervals | 1 | 1 | time | %ThresholdHR | 0 | — | — |
| Fartlek Training | 1 | 1 | time | %ThresholdHR | 0 | — | — |
| Threshold Intervals | 1 | 1 | distance, time | %ThresholdHR | 0 | — | mixed duration units: distance, time |
| Marathon Pace Long Run | 1 | 1 | time | %ThresholdHR | 0 | — | — |
| Track 100m Strides | 1 | 1 | distance | %ThresholdHR, RPE | 0 | — | — |
| Track 200m Repeats | 1 | 1 | distance | %ThresholdHR, RPE | 0 | — | — |
| Track 400m Repeats | 1 | 1 | distance, time | %ThresholdHR, RPE, rest | 0 | — | mixed duration units: distance, time |
| Track Yasso 800s | 1 | 1 | distance | %ThresholdHR, RPE | 0 | — | — |
| Track Mile Repeats | 1 | 1 | distance | %ThresholdHR, RPE | 0 | — | — |
| Track Ladder Activity | 2 | 2 | distance, time | %ThresholdHR, RPE, rest | 0 | — | mixed duration units: distance, time |
| Outdoor Sweet Spot Intervals | 1 | 1 | time | %FTP | 0 | — | — |
| Tempo Intervals | 1 | 1 | time | %FTP | 0 | — | — |
| Climbing Intervals | 1 | 1 | time | %FTP | 0 | — | — |
| Group Ride Simulation | 1 | 1 | time | %FTP, RPE | 0 | — | — |
| Progressive Long Endurance Ride | 1 | 1 | time | %FTP | 0 | — | — |
| Tempo Control Intervals | 1 | 1 | time | %FTP | 0 | — | — |
| Threshold Power Intervals | 1 | 1 | time | %FTP | 0 | — | — |
| Anaerobic Repeatability | 1 | 1 | time | %FTP | 0 | — | — |
| Neuromuscular Sprint Set | 1 | 1 | time | %FTP | 0 | — | — |
| Cadence Endurance Blocks | 1 | 1 | time | %FTP, cadence | 0 | — | — |
| Cruise Tempo Run | 1 | 1 | time | RPE | 0 | — | — |
| Anaerobic Hill Surges | 1 | 1 | time | RPE | 0 | — | — |
| Neuromuscular Strides | 1 | 1 | time | RPE | 0 | — | — |
| Recovery Feel Swim | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| Aerobic Continuity Swim | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| Tempo Pull Set | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| CSS Threshold Swim | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| VO2 Pace Swim | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| Anaerobic 50s | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| Neuromuscular 25s | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| Sighting Endurance Swim | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| Tempo Negative-Split Swim | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| Movement Capacity Strength | 1 | 1 | repetitions, time | RPE, rest | 0 | — | mixed duration units: repetitions, time |
| Compound Strength | 2 | 2 | repetitions, time | RPE, rest | 0 | — | mixed duration units: repetitions, time |
| Single-Leg Control | 2 | 2 | repetitions, time | RPE, rest | 0 | — | mixed duration units: repetitions, time |
| Power Production | 1 | 1 | repetitions, time | RPE, rest | 0 | — | mixed duration units: repetitions, time |
| Trunk and Carry Strength | 1 | 1 | repetitions, time | RPE, rest | 0 | — | mixed duration units: repetitions, time |
| Mobility Reset | 2 | 2 | time | RPE | 0 | — | — |
| Yoga Balance Flow | 2 | 2 | time | RPE | 0 | — | — |
| Norwegian 4×4 Run | 1 | 1 | time | %MaxHR | 0 | — | — |
| Norwegian Controlled Threshold Long Repeats | 1 | 1 | distance, time | RPE | 0 | — | mixed duration units: distance, time |
| Norwegian 25×400 Controlled Threshold | 1 | 1 | distance, time | RPE | 0 | — | mixed duration units: distance, time |
| Critical Swim Speed (CSS) | 1 | 1 | distance, time | RPE, rest | 0 | — | mixed duration units: distance, time |
| Full Body Circuit | 1 | 1 | time | RPE | 0 | — | — |
| Core and Stability | 1 | 1 | time | RPE | 0 | — | — |
| Functional Movement | 1 | 1 | time | RPE | 0 | — | — |
| Upper Body Strength | 2 | 2 | repetitions, time | RPE, rest | 0 | — | mixed duration units: repetitions, time |
| Lower Body Strength | 2 | 2 | repetitions, time | RPE, rest | 0 | — | mixed duration units: repetitions, time |
| Sprint Intervals | 1 | 1 | distance | %ThresholdHR | 0 | — | — |
| Threshold Set | 1 | 1 | distance | %ThresholdHR | 0 | — | — |
| Technique Focus | 1 | 1 | distance | %ThresholdHR | 0 | — | — |
| Endurance Set | 1 | 1 | distance | %ThresholdHR | 0 | — | — |
| Rowing Erg Threshold Intervals | 1 | 1 | time | RPE | 0 | — | — |
